"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { Conversation } from "./ChatBox";

type SidebarProps = {
  conversations?: Conversation[];
  activeConversationId?: string;
  onSelectConversation?: (conversationId: string) => void;
  onCreateConversation?: () => void;
};

const navItems = [
  { icon: "📊", label: "Dashboard", href: "/dashboard" },
  { icon: "📈", label: "Analytics", href: "/dashboard" },
  { icon: "💬", label: "Chat History", href: "/" },
];

export default function Sidebar({
  conversations,
  activeConversationId,
  onSelectConversation,
  onCreateConversation,
}: SidebarProps) {
  const pathname = usePathname();

  return (
    <aside className="hidden h-[calc(100vh-3rem)] w-full max-w-xs shrink-0 rounded-[2rem] bg-slate-950 px-6 py-8 text-slate-100 shadow-[0_36px_80px_rgba(15,23,42,0.35)] lg:flex lg:flex-col lg:justify-between">
      <div>
        <div className="mb-10">
          <p className="text-sm uppercase tracking-[0.28em] text-slate-500">Workspace</p>
          <h2 className="mt-4 text-3xl font-semibold text-white">MetricMind</h2>
          <p className="mt-3 max-w-[18rem] text-sm text-slate-400">
            A friendly sidebar for chat commands and quick analytics shortcuts.
          </p>
        </div>

        <nav className="mb-8 space-y-3 text-sm leading-7 text-slate-300">
          {navItems.map((item) => {
            const isActive = pathname === item.href;

            return (
              <Link
                key={item.label}
                href={item.href}
                className={`flex w-full items-center gap-3 rounded-2xl border px-4 py-3 text-left transition ${
                  isActive
                    ? "border-sky-500 bg-sky-500/15 text-white"
                    : "border-slate-800 bg-slate-900 text-slate-300 hover:border-amber-400 hover:text-amber-200"
                }`}
              >
                <span className="text-base">{item.icon}</span>
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {conversations && (
          <div className="mb-6 rounded-[1.5rem] border border-slate-800 bg-slate-900/70 p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <p className="text-sm uppercase tracking-[0.25em] text-slate-500">History</p>
              <button
                type="button"
                onClick={onCreateConversation}
                className="rounded-full bg-sky-500/20 px-3 py-1 text-xs font-semibold text-sky-200 transition hover:bg-sky-500/30"
              >
                New chat
              </button>
            </div>

            <div className="max-h-[16rem] space-y-2 overflow-y-auto pr-1">
              {conversations.map((conversation) => {
                const isActive = activeConversationId === conversation.id;

                return (
                  <button
                    key={conversation.id}
                    type="button"
                    onClick={() => onSelectConversation?.(conversation.id)}
                    className={`w-full rounded-2xl border px-3 py-3 text-left transition ${
                      isActive
                        ? "border-sky-500 bg-sky-500/15"
                        : "border-slate-800 bg-slate-900/80 hover:border-slate-700 hover:bg-slate-900"
                    }`}
                  >
                    <p className="truncate text-sm font-medium text-white">{conversation.title}</p>
                    <p className="mt-1 text-xs text-slate-400">{conversation.updatedAt}</p>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {conversations && (
        <div className="rounded-[1.75rem] border border-slate-800 bg-slate-900 p-5 text-sm text-slate-300">
          <p className="text-sm uppercase tracking-[0.25em] text-slate-500">Quick prompts</p>
          <ul className="mt-4 space-y-3">
            <li className="rounded-2xl bg-slate-900/80 px-4 py-3 transition hover:bg-slate-900">
              How did sales perform this week?
            </li>
            <li className="rounded-2xl bg-slate-900/80 px-4 py-3 transition hover:bg-slate-900">
              Show trend comparisons.
            </li>
            <li className="rounded-2xl bg-slate-900/80 px-4 py-3 transition hover:bg-slate-900">
              Summarize customer feedback.
            </li>
          </ul>
        </div>
      )}
    </aside>
  );
}
