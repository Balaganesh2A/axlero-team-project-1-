import { dimensions, measures, synonyms } from "./schema.ts";
import type { CubeFilter, CubeQuery, CubeQueryResult } from "./types.ts";

/**
 * Parse a natural language business question into a Cube.dev query object.
 * The implementation uses deterministic keyword matching so it can run without
 * a live LLM dependency while preserving a reusable structure for later LLM integration.
 */
export function parseCubeQuery(question: string): CubeQueryResult {
  const normalized = question.trim().toLowerCase();

  if (!normalized) {
    return { error: "Unknown Measure" };
  }

  const measuresFound = detectMeasures(normalized);
  const dimensionsFound = detectDimensions(normalized);
  const timeDimensionsFound = detectTimeDimensions(normalized);
  const filter = detectFilter(normalized);
  const sortingFound = detectSorting(normalized, measuresFound);

  if (!measuresFound.length) {
    return { error: "Unknown Measure" };
  }

  if (hasUnsupportedDimensionContext(normalized, dimensionsFound, timeDimensionsFound, filter)) {
    return { error: "Unknown Dimension" };
  }

  if (normalized.includes("employee") || normalized.includes("salary") || normalized.includes("office") || normalized.includes("rent") || normalized.includes("manager") || normalized.includes("bonus")) {
    return { error: "Unknown Measure" };
  }

  const query: CubeQuery = {
    measures: measuresFound,
  };

  if (dimensionsFound.length) {
    query.dimensions = dimensionsFound;
  }

  if (timeDimensionsFound.length) {
    query.timeDimensions = timeDimensionsFound;
  }

  if (filter) {
    query.filters = [filter];
  }

  if (sortingFound.length) {
    query.sorting = sortingFound;
  }

  return { query };
}

function detectMeasures(question: string): string[] {
  const matchedMeasures = new Set<string>();

  if (/profit margin/.test(question)) {
    matchedMeasures.add("orders.profit_margin");
  }

  if (/\bmargin\b/.test(question) && !/profit margin/.test(question)) {
    return [];
  }

  for (const [synonym, measure] of Object.entries(synonyms)) {
    if (question.includes(synonym) && !/profit margin/.test(question)) {
      matchedMeasures.add(measure);
    }
  }

  if (question.includes("profit") && !question.includes("margin")) {
    matchedMeasures.add("orders.total_profit");
  }

  if (matchedMeasures.size === 0) {
    return [];
  }

  return Array.from(matchedMeasures).filter((measure): measure is string => measures.includes(measure as (typeof measures)[number]));
}

function detectDimensions(question: string): string[] {
  const matchedDimensions = new Set<string>();

  if (/(by|for|show|count).*/.test(question)) {
    // Keep parsing intentionally simple and deterministic.
  }

  if (/(category|categories)/.test(question)) {
    matchedDimensions.add("orders.category");
  }

  if (/(region|regions)/.test(question)) {
    matchedDimensions.add("orders.region");
  }

  if (/(date|day|month|year)/.test(question)) {
    matchedDimensions.add("orders.order_date");
  }

  if (/(customer|buyer)/.test(question)) {
    matchedDimensions.add("orders.customer_name");
  }

  if (/(product|item)/.test(question)) {
    matchedDimensions.add("orders.product_name");
  }

  return Array.from(matchedDimensions).filter((dimension): dimension is string => dimensions.includes(dimension as (typeof dimensions)[number]));
}

function detectFilter(question: string): CubeFilter | null {
  if (/for\s+technology/.test(question)) {
    return {
      member: "orders.category",
      operator: "equals",
      values: ["Technology"],
    };
  }

  const match = /\bfor\s+([a-z0-9\s-]+)$/.exec(question);
  if (!match) {
    return null;
  }

  const value = match[1].trim();
  if (!value) {
    return null;
  }

  if (/\bcustomer\b/.test(question)) {
    return { member: "orders.customer_name", operator: "equals", values: [value] };
  }

  if (/\bproduct\b/.test(question)) {
    return { member: "orders.product_name", operator: "equals", values: [value] };
  }

  if (/\bregion\b/.test(question)) {
    return { member: "orders.region", operator: "equals", values: [value] };
  }

  if (/\bcategory\b/.test(question)) {
    return { member: "orders.category", operator: "equals", values: [value] };
  }

  if (/\bdate\b|\border date\b/.test(question)) {
    return { member: "orders.order_date", operator: "equals", values: [value] };
  }

  return {
    member: "orders.category",
    operator: "equals",
    values: [value],
  };
}

function detectSorting(question: string, measuresFound: string[]): Array<{ field: string; direction: "asc" | "desc"; limit?: number }> {
  const sorts: Array<{ field: string; direction: "asc" | "desc"; limit?: number }> = [];

  const topMatch = /\btop\s+(\d+)\b/.exec(question);
  const lowestMatch = /\blowest\s+(\d+)\b/.exec(question);
  const highestMatch = /\bhighest\b/.exec(question);
  const ascendingMatch = /\bascending\b/.exec(question);
  const descendingMatch = /\bdescending\b/.exec(question);

  if (topMatch || highestMatch || descendingMatch) {
    const limit = topMatch ? Number.parseInt(topMatch[1], 10) : undefined;
    const measure = measuresFound[0] ?? "orders.total_sales";
    sorts.push({ field: measure, direction: "desc", ...(limit ? { limit } : {}) });
  }

  if (lowestMatch || ascendingMatch) {
    const limit = lowestMatch ? Number.parseInt(lowestMatch[1], 10) : undefined;
    const measure = measuresFound[0] ?? "orders.total_profit";
    sorts.push({ field: measure, direction: "asc", ...(limit ? { limit } : {}) });
  }

  return sorts;
}

function detectTimeDimensions(question: string): string[] {
  const matchedTimeDimensions = new Set<string>();

  if (/\byear\b/.test(question)) matchedTimeDimensions.add("Year");
  if (/\bquarter\b/.test(question)) matchedTimeDimensions.add("Quarter");
  if (/\bmonth\b/.test(question)) matchedTimeDimensions.add("Month");
  if (/\bdate\b/.test(question)) matchedTimeDimensions.add("Date");

  return Array.from(matchedTimeDimensions);
}

function hasUnsupportedDimensionContext(question: string, dimensionsFound: string[], timeDimensionsFound: string[], filter: CubeFilter | null): boolean {
  if (dimensionsFound.length || timeDimensionsFound.length || filter) {
    return false;
  }

  const byClause = /\bby\s+([a-z]+(?:\s+[a-z]+)*)/.exec(question);
  if (byClause) {
    const value = byClause[1].trim();
    return !/^(category|categories|region|regions|date|day|month|year|customer|buyer|product|item)$/.test(value);
  }

  const forClause = /\bfor\s+([a-z0-9\s-]+)$/.exec(question);
  if (forClause) {
    const value = forClause[1].trim();
    return !/^(technology|[a-z]+)$/.test(value);
  }

  return false;
}
