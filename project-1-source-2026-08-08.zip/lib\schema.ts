// Central schema definitions for the Cube.dev semantic model.
// Keep this list restricted to the currently supported current Cube schema.
export const measures = [
  "orders.total_sales",
  "orders.total_profit",
  "orders.total_quantity",
  "orders.count",
] as const;

export const dimensions = [
  "orders.category",
  "orders.region",
  "orders.product_name",
  "orders.customer_name",
  "orders.order_date",
] as const;

export const timeDimensions = ["Year", "Quarter", "Month", "Date"] as const;

export const synonyms: Record<string, string> = {
  sales: "orders.total_sales",
  revenue: "orders.total_sales",
  earnings: "orders.total_profit",
  profit: "orders.total_profit",
  quantity: "orders.total_quantity",
  orders: "orders.count",
  "number of orders": "orders.count",
  product: "orders.product_name",
  customer: "orders.customer_name",
  category: "orders.category",
  region: "orders.region",
  date: "orders.order_date",
};

export type Measure = (typeof measures)[number];
export type Dimension = (typeof dimensions)[number];
export type TimeDimension = (typeof timeDimensions)[number];
