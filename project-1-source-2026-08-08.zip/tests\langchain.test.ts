import test from "node:test";
import assert from "node:assert/strict";

import { createCubeQueryAgent, generateCubeQuery } from "../lib/langchain.ts";

test("maps sales by category to a Cube query", async () => {
  const result = await generateCubeQuery("Show sales by category");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_sales"],
      dimensions: ["orders.category"],
    },
  });
});

test("maps profit by region to a Cube query", async () => {
  const result = await generateCubeQuery("Show profit by region");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_profit"],
      dimensions: ["orders.region"],
    },
  });
});

test("maps quantity requests to a measure-only Cube query", async () => {
  const result = await generateCubeQuery("Show quantity");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_quantity"],
    },
  });
});

test("rejects average order value as a planned future field", async () => {
  const result = await generateCubeQuery("Show average order value by region");

  assert.deepEqual(result, {
    error: "Unknown Measure",
  });
});

test("rejects profit margin as a planned future field", async () => {
  const result = await generateCubeQuery("Show profit margin");

  assert.deepEqual(result, {
    error: "Unknown Measure",
  });
});

test("maps count all orders to a Cube query", async () => {
  const result = await generateCubeQuery("Count all orders");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.count"],
    },
  });
});

test("rejects unknown measures or dimensions", async () => {
  const result = await generateCubeQuery("Show employee salary");

  assert.deepEqual(result, {
    error: "Unknown Measure",
  });
});

test("supports a custom fallback parser for deterministic execution", async () => {
  const agent = createCubeQueryAgent({
    fallbackParser: () => ({ query: { measures: ["orders.count"] } }),
  });

  const result = await agent("Count all orders");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.count"],
    },
  });
});
