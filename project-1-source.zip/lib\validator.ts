import { dimensions, measures, timeDimensions } from "./schema.ts";
import type { CubeQueryResult } from "./types.ts";

/**
 * Validate a generated Cube.dev query and return descriptive errors for invalid fields.
 */
export function validateCubeQuery(result: CubeQueryResult): CubeQueryResult {
  if (result.error) {
    return result;
  }

  if (!result.query) {
    return { error: "Unknown Measure" };
  }

  const allowedMeasures = new Set(measures);
  const allowedDimensions = new Set(dimensions);
  const allowedTimeDimensions = new Set(timeDimensions);

  const measuresToValidate = result.query.measures ?? [];
  const dimensionsToValidate = result.query.dimensions ?? [];
  const filtersToValidate = result.query.filters ?? [];
  const timeDimensionsToValidate = result.query.timeDimensions ?? [];

  const hasUnknownMeasure = measuresToValidate.some((measure) => !allowedMeasures.has(measure));
  const hasUnknownDimension = dimensionsToValidate.some((dimension) => !allowedDimensions.has(dimension));

  if (hasUnknownMeasure) {
    return { error: "Unknown Measure" };
  }

  if (hasUnknownDimension) {
    return { error: "Unknown Dimension" };
  }

  const hasUnknownFilter = filtersToValidate.some((filter) => !allowedDimensions.has(filter.member));
  if (hasUnknownFilter) {
    return { error: "Unknown Filter" };
  }

  const hasUnknownTimeDimension = timeDimensionsToValidate.some((timeDimension) => !allowedTimeDimensions.has(timeDimension as (typeof timeDimensions)[number]));
  if (hasUnknownTimeDimension) {
    return { error: "Unknown Time Dimension" };
  }

  return result;
}
