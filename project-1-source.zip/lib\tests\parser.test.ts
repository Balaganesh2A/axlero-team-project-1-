import test from "node:test";
import assert from "node:assert/strict";

import { createCubeQueryAgent, generateCubeQuery } from "../langchain.ts";

test("maps total sales by category to a Cube query", async () => {
  const result = await generateCubeQuery("Show total sales by category");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_sales"],
      dimensions: ["orders.category"],
    },
  });
});

test("maps profit by region to a Cube query", async () => {
  const result = await generateCubeQuery("Show profit by region");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_profit"],
      dimensions: ["orders.region"],
    },
  });
});

test("maps sales for Technology to a filter query", async () => {
  const result = await generateCubeQuery("Show sales for Technology");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_sales"],
      filters: [
        {
          member: "orders.category",
          operator: "equals",
          values: ["Technology"],
        },
      ],
    },
  });
});

test("maps sales and profit by country to a multi-measure query", async () => {
  const result = await generateCubeQuery("Show sales and profit by country");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_sales", "orders.total_profit"],
      dimensions: ["orders.country"],
    },
  });
});

test("maps count all orders to a count query", async () => {
  const result = await generateCubeQuery("Count all orders");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.count"],
    },
  });
});

test("rejects unknown measures", async () => {
  const result = await generateCubeQuery("Show employee salary");

  assert.deepEqual(result, {
    error: "Unknown Measure",
  });
});

test("rejects invalid dimensions", async () => {
  const result = await generateCubeQuery("Show sales by department");

  assert.deepEqual(result, {
    error: "Unknown Dimension",
  });
});

test("rejects invalid measures", async () => {
  const result = await generateCubeQuery("Show margin by region");

  assert.deepEqual(result, {
    error: "Unknown Measure",
  });
});

test("maps time-based questions to time dimensions", async () => {
  const result = await generateCubeQuery("Show sales by month");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_sales"],
      dimensions: ["orders.order_date"],
      timeDimensions: ["Month"],
    },
  });
});

test("falls back to the parser when the LangChain chain is unavailable", async () => {
  const agent = createCubeQueryAgent({
    fallbackParser: () => ({ query: { measures: ["orders.total_sales"], dimensions: ["orders.category"] } }),
  });

  const result = await agent("Show total sales by category");

  assert.deepEqual(result, {
    query: {
      measures: ["orders.total_sales"],
      dimensions: ["orders.category"],
    },
  });
});
