import dotenv from "dotenv";
import { JsonOutputParser } from "@langchain/core/output_parsers";
import { ChatPromptTemplate } from "@langchain/core/prompts";
import type { BaseChatModel } from "@langchain/core/language_models/chat_models";
import { ChatOpenAI } from "@langchain/openai";

import { cubeQuerySystemPrompt } from "./prompts.ts";
import { parseCubeQuery } from "./parser.ts";
import { validateCubeQuery } from "./validator.ts";
import type { CubeQueryResult, GenerateCubeQueryOptions } from "./types.ts";

dotenv.config();

const parser = new JsonOutputParser<CubeQueryResult>();

/**
 * Create a LangChain prompt that instructs the model to return only valid JSON.
 * The prompt also includes the available Cube measures and dimensions.
 */
function escapePromptBraces(value: string): string {
  return value.replace(/\{/g, "{{").replace(/\}/g, "}}");
}

function createPrompt() {
  const systemContent = escapePromptBraces(`${cubeQuerySystemPrompt}\n\n${parser.getFormatInstructions()}`);

  return ChatPromptTemplate.fromMessages([
    ["system", systemContent],
    ["human", "Business question: {question}"],
  ]);
}

/**
 * Resolve a chat model from dependency injection first, then from environment
 * variables. This keeps the module easy to swap for OpenAI, Ollama, or another
 * provider later.
 */
function createLanguageModel(options?: GenerateCubeQueryOptions): BaseChatModel | null {
  if (options?.llm) {
    return options.llm;
  }

  const provider = process.env.LLM_PROVIDER ?? process.env.LANGCHAIN_PROVIDER ?? "openai";
  if (provider !== "openai") {
    return null;
  }

  const apiKey = process.env.OPENAI_API_KEY;
  const modelName = process.env.MODEL_NAME ?? "gpt-4o-mini";

  if (!apiKey) {
    return null;
  }

  return new ChatOpenAI({
    model: modelName,
    temperature: 0,
    apiKey,
    maxRetries: 1,
  }) as unknown as BaseChatModel;
}

/**
 * Build the LCEL chain that runs the prompt through the LLM and then through the
 * structured output parser. This is the new AI-powered path.
 */
function createLangChainChain(options?: GenerateCubeQueryOptions) {
  const prompt = createPrompt();
  const llm = createLanguageModel(options);

  if (!llm) {
    return null;
  }

  return prompt.pipe(llm).pipe(parser);
}

/**
 * Create a reusable Cube query agent. The agent first tries the LangChain path,
 * then falls back to the deterministic parser if the LLM output is missing or
 * invalid.
 */
export function createCubeQueryAgent(options: GenerateCubeQueryOptions = {}) {
  return async function generate(question: string): Promise<CubeQueryResult> {
    const fallbackParser = options.fallbackParser ?? parseCubeQuery;
    const fallbackResult = validateCubeQuery(fallbackParser(question));

    const chain = createLangChainChain(options);
    if (!chain) {
      return fallbackResult;
    }

    try {
      const parsed = await chain.invoke({ question });
      const candidate = validateCubeQuery(parsed as CubeQueryResult);

      if (candidate.error || !candidate.query) {
        return fallbackResult;
      }

      return candidate;
    } catch (error) {
      console.warn("Cube query generation failed, falling back to parser.", error);
      return fallbackResult;
    }
  };
}

/**
 * Public entry point for the module.
 *
 * Example:
 * const result = await generateCubeQuery("Show total sales by category");
 */
export async function generateCubeQuery(question: string, options: GenerateCubeQueryOptions = {}): Promise<CubeQueryResult> {
  return createCubeQueryAgent(options)(question);
}

export { cubeQuerySystemPrompt };
