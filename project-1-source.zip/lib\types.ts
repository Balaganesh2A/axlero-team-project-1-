/**
 * Shared types for the Cube.dev query generation pipeline.
 */
import type { BaseChatModel } from "@langchain/core/language_models/chat_models";

export interface CubeFilter {
  member: string;
  operator: "equals";
  values: string[];
}

export interface CubeQuery {
  measures?: string[];
  dimensions?: string[];
  filters?: CubeFilter[];
  timeDimensions?: string[];
}

export interface ParsedCubeQuery extends CubeQuery {
  timeDimensions?: string[];
}

export interface CubeQueryResult {
  query?: CubeQuery;
  error?: string;
}

export interface GenerateCubeQueryOptions {
  /**
   * Optional injected chat model. If omitted, the module tries to create a
   * model from environment variables.
   */
  llm?: BaseChatModel;
  /**
   * Optional parser fallback override for tests or alternate implementations.
   */
  fallbackParser?: (question: string) => CubeQueryResult;
}
