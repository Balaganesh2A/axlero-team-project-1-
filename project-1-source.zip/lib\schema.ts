// Central schema definitions for the Cube.dev semantic model.
export const measures = [
  "orders.total_sales",
  "orders.total_profit",
  "orders.total_quantity",
  "orders.total_cost",
  "orders.average_order_value",
  "orders.profit_margin",
  "orders.count",
] as const;

export const dimensions = [
  "orders.category",
  "orders.region",
  "orders.country",
  "orders.order_date",
  "orders.customer_name",
  "orders.product_name",
  "orders.order_id",
] as const;

export const timeDimensions = ["Year", "Quarter", "Month", "Date"] as const;

export const synonyms: Record<string, string> = {
  sales: "orders.total_sales",
  revenue: "orders.total_sales",
  profit: "orders.total_profit",
  quantity: "orders.total_quantity",
  orders: "orders.count",
  "average order value": "orders.average_order_value",
  "profit margin": "orders.profit_margin",
};

export type Measure = (typeof measures)[number];
export type Dimension = (typeof dimensions)[number];
export type TimeDimension = (typeof timeDimensions)[number];
