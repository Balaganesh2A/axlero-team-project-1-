﻿type MessageProps = {
  text: string;
  sender: "user" | "bot";
  timestamp: string;
};

export default function Message({
  text,
  sender,
  timestamp,
}: MessageProps) {
  const isUser = sender === "user";

  return (
    <div className={`flex w-full ${isUser ? "justify-end" : "justify-start"}`}>
      <div className={`flex max-w-[min(90%,40rem)] flex-col gap-2 ${isUser ? "items-end" : "items-start"}`}>
        <span className="text-[11px] uppercase tracking-[0.25em] text-slate-400">
          {isUser ? "User" : "Bot"}
        </span>
        <div
          className={`max-w-full rounded-[1.6rem] px-4 py-3 text-[15px] leading-6 shadow-sm transition-all sm:px-5 sm:py-4 ${
            isUser
              ? "rounded-br-[0.35rem] bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600 text-white shadow-sky-500/20"
              : "rounded-bl-[0.35rem] border border-slate-200 bg-white text-slate-900 shadow-slate-200"
          }`}
        >
          <p className="whitespace-pre-wrap break-words">{text}</p>
        </div>
        <span className="text-[11px] text-slate-500">{timestamp}</span>
      </div>
    </div>
  );
}
